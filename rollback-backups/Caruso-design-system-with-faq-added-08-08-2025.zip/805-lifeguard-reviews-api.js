// === 805 LIFEGUARD REVIEWS API - CLOUDFLARE WORKER (PRODUCTION - MANUAL YELP) ===
// Handles Google API + Manual Yelp reviews for both staging and production domains

export default {
    async fetch(request, env, ctx) {
        return handleRequest(request, env);
    }
};

async function handleRequest(request, env) {
    const url = new URL(request.url);
    
    // MULTI-DOMAIN CORS CONFIGURATION
    const allowedOrigins = [
        'https://luxury.805companies.com',      // Staging domain
        'https://805lifeguard.com',             // Production domain
        'https://www.805lifeguard.com',         // Production www variant
        'http://localhost:3000',                // Local development
        'http://localhost:8080',                // Local development alt
        'http://127.0.0.1:3000',               // Local development IP
    ];
    
    // Get the origin from the request
    const origin = request.headers.get('Origin');
    const isAllowedOrigin = allowedOrigins.includes(origin);
    
    // Dynamic CORS headers based on request origin
    const corsHeaders = {
        'Access-Control-Allow-Origin': isAllowedOrigin ? origin : allowedOrigins[0],
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Accept, User-Agent, X-Requested-With, Origin',
        'Access-Control-Allow-Credentials': 'false',
        'Access-Control-Max-Age': '86400',
        'Vary': 'Origin',
    };

    // Enhanced logging for debugging
    console.log('805 LifeGuard API Request:', {
        method: request.method,
        path: url.pathname,
        origin: origin,
        isAllowedOrigin: isAllowedOrigin,
        timestamp: new Date().toISOString()
    });

    // Handle preflight requests
    if (request.method === 'OPTIONS') {
        return new Response(null, { 
            status: 204,
            headers: corsHeaders 
        });
    }

    // Only allow GET requests for reviews
    if (request.method !== 'GET') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), {
            status: 405,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }

    try {
        // Route API requests
        if (url.pathname === '/api/google-reviews') {
            return await handleGoogleReviews(env, corsHeaders, origin);
        } else if (url.pathname.startsWith('/api/yelp-reviews/')) {
            return await handleYelpReviewsManual(corsHeaders, origin);
        } else if (url.pathname === '/api/reviews/combined') {
            return await handleCombinedReviews(env, corsHeaders, origin);
        } else if (url.pathname === '/api/health') {
            return await handleHealthCheck(corsHeaders, origin);
        } else if (url.pathname === '/api/config') {
            return await handleConfigCheck(env, corsHeaders, origin);
        }
        
        return new Response(JSON.stringify({ 
            error: 'Endpoint not found',
            available_endpoints: [
                '/api/google-reviews',
                '/api/yelp-reviews/{business-id} (manual)',
                '/api/reviews/combined',
                '/api/health',
                '/api/config'
            ],
            domain: getDomainInfo(origin)
        }), {
            status: 404,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        console.error('805 LifeGuard API Error:', error);
        return new Response(JSON.stringify({ 
            error: 'Internal server error',
            message: error.message,
            fallback: true,
            timestamp: new Date().toISOString(),
            domain: getDomainInfo(origin)
        }), { 
            status: 500, 
            headers: { 
                ...corsHeaders, 
                'Content-Type': 'application/json' 
            } 
        });
    }
}

// === DOMAIN INFORMATION HELPER ===
function getDomainInfo(origin) {
    if (!origin) return { type: 'unknown', environment: 'unknown' };
    
    if (origin.includes('luxury.805companies.com')) {
        return { 
            type: 'staging', 
            environment: 'staging',
            domain: 'luxury.805companies.com',
            target: '805lifeguard.com'
        };
    } else if (origin.includes('805lifeguard.com')) {
        return { 
            type: 'production', 
            environment: 'production',
            domain: '805lifeguard.com',
            target: '805lifeguard.com'
        };
    } else if (origin.includes('localhost') || origin.includes('127.0.0.1')) {
        return { 
            type: 'development', 
            environment: 'development',
            domain: origin,
            target: 'localhost'
        };
    }
    
    return { type: 'unknown', environment: 'unknown', domain: origin };
}

// === ENHANCED HEALTH CHECK WITH DOMAIN INFO ===
async function handleHealthCheck(corsHeaders, origin) {
    const domainInfo = getDomainInfo(origin);
    
    return new Response(JSON.stringify({
        status: 'healthy',
        service: '805 LifeGuard Reviews API',
        version: '2.4',
        timestamp: new Date().toISOString(),
        domain_info: domainInfo,
        configuration: {
            google_api: 'enabled',
            yelp_api: 'manual_reviews_only',
            multi_domain: 'enabled'
        },
        endpoints: {
            google: '/api/google-reviews',
            yelp: '/api/yelp-reviews/{business-id} (manual)',
            combined: '/api/reviews/combined',
            config: '/api/config'
        },
        cors_enabled: true,
        multi_domain_support: true
    }), {
        headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Cache-Control': 'public, max-age=60'
        }
    });
}

// === UPDATED CONFIGURATION CHECK ENDPOINT ===
async function handleConfigCheck(env, corsHeaders, origin) {
    const domainInfo = getDomainInfo(origin);
    
    // Check if environment variables are configured
    const hasGoogleKey = !!env.GOOGLE_PLACES_API_KEY;
    const hasPlaceId = !!env.GOOGLE_PLACE_ID;
    
    // Yelp is intentionally manual - not an error condition
    const isProductionReady = hasGoogleKey; // Only Google API required
    
    return new Response(JSON.stringify({
        domain_info: domainInfo,
        api_configuration: {
            google_places_api: hasGoogleKey ? 'configured' : 'missing',
            yelp_fusion_api: 'manual_reviews_only', // Intentionally manual
            google_place_id: hasPlaceId ? 'configured' : 'using_default',
            ready_for_production: isProductionReady
        },
        environment: {
            is_staging: domainInfo.type === 'staging',
            is_production: domainInfo.type === 'production',
            is_development: domainInfo.type === 'development'
        },
        switch_readiness: {
            cors_configured: true,
            apis_ready: isProductionReady,
            domain_ready: true,
            yelp_strategy: 'manual_reviews',
            recommendation: isProductionReady ? 'Ready for domain switch' : 'Configure Google API before production switch'
        },
        features: {
            live_google_reviews: hasGoogleKey,
            manual_yelp_reviews: true,
            multi_domain_support: true,
            graceful_fallback: true
        },
        timestamp: new Date().toISOString()
    }), {
        headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Cache-Control': 'private, max-age=0'
        }
    });
}

// === ENHANCED GOOGLE PLACES API HANDLER ===
async function handleGoogleReviews(env, corsHeaders, origin) {
    const GOOGLE_API_KEY = env.GOOGLE_PLACES_API_KEY;
    const PLACE_ID = env.GOOGLE_PLACE_ID || 'ChIJF_n_aeIx6IARDaz-6Q4-Hec';
    const domainInfo = getDomainInfo(origin);
    
    if (!GOOGLE_API_KEY || !PLACE_ID) {
        console.warn('805 LifeGuard: Google API credentials not configured for', domainInfo.environment);
        return new Response(JSON.stringify({ 
            error: 'Google API not configured',
            fallback: true,
            message: `Using fallback data - API credentials missing for ${domainInfo.environment}`,
            domain_info: domainInfo,
            timestamp: new Date().toISOString()
        }), { 
            status: 200,
            headers: { 
                ...corsHeaders, 
                'Content-Type': 'application/json',
                'Cache-Control': 'public, max-age=300'
            } 
        });
    }

    try {
        const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${PLACE_ID}&fields=reviews,rating,user_ratings_total,name&key=${GOOGLE_API_KEY}`;
        
        const response = await fetchWithTimeout(url, {
            headers: {
                'User-Agent': `805LifeGuard-API/2.4-${domainInfo.environment}`,
                'Accept': 'application/json',
                'Referer': origin || 'https://805lifeguard.com'
            }
        }, 10000);
        
        if (!response.ok) {
            throw new Error(`Google API HTTP error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.status !== 'OK') {
            console.error('805 LifeGuard: Google API status error:', data.status, data.error_message);
            throw new Error(`Google API error: ${data.status} - ${data.error_message || 'Unknown error'}`);
        }

        const result = data.result;
        const reviews = result.reviews || [];
        
        // Enhanced review processing
        const processedReviews = reviews
            .filter(review => {
                return review.rating >= 4 && 
                       review.text && 
                       review.text.length > 20 &&
                       review.text.length < 1000;
            })
            .map(review => ({
                author_name: sanitizeText(review.author_name),
                rating: Math.min(5, Math.max(1, review.rating)),
                text: sanitizeText(review.text),
                time: review.time * 1000,
                relative_time_description: review.relative_time_description || 'recently',
                profile_photo_url: review.profile_photo_url || '',
                source: 'google',
                processed_at: new Date().toISOString()
            }))
            .slice(0, 12);

        const responseData = {
            success: true,
            reviews: processedReviews,
            summary: {
                rating: Math.round((result.rating || 5.0) * 10) / 10,
                total_ratings: result.user_ratings_total || 0,
                business_name: sanitizeText(result.name) || '805 LifeGuard',
                review_count: processedReviews.length
            },
            source: 'google',
            domain_info: domainInfo,
            timestamp: new Date().toISOString(),
            cache_duration: 1800,
            api_version: '2.4'
        };

        return new Response(JSON.stringify(responseData), {
            headers: { 
                ...corsHeaders, 
                'Content-Type': 'application/json',
                'Cache-Control': 'public, max-age=1800, s-maxage=1800'
            }
        });

    } catch (error) {
        console.error('805 LifeGuard: Google API fetch error for', domainInfo.environment, ':', error);
        
        return new Response(JSON.stringify({ 
            error: 'Failed to fetch Google reviews',
            message: error.message,
            fallback: true,
            domain_info: domainInfo,
            timestamp: new Date().toISOString(),
            retry_after: 300
        }), { 
            status: 200,
            headers: { 
                ...corsHeaders, 
                'Content-Type': 'application/json',
                'Cache-Control': 'public, max-age=60'
            } 
        });
    }
}

// === MANUAL YELP REVIEWS HANDLER ===
async function handleYelpReviewsManual(corsHeaders, origin) {
    const domainInfo = getDomainInfo(origin);
    
    // Return structured response indicating manual reviews are used
    return new Response(JSON.stringify({ 
        success: true,
        reviews: [], // Empty - frontend will use manual reviews from HTML
        summary: {
            rating: 5.0,
            review_count: 8, // Update this number when you add more manual reviews
            business_name: '805 LifeGuard',
            total_reviews: 0,
            manual_reviews_note: 'Reviews are manually curated in HTML for quality control'
        },
        source: 'yelp',
        method: 'manual',
        domain_info: domainInfo,
        message: 'Using manually curated Yelp reviews for quality control',
        timestamp: new Date().toISOString(),
        api_version: '2.4'
    }), { 
        status: 200,
        headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Cache-Control': 'public, max-age=3600' // Cache manual response longer
        } 
    });
}

// === ENHANCED COMBINED REVIEWS (Google API + Manual Yelp) ===
async function handleCombinedReviews(env, corsHeaders, origin) {
    const domainInfo = getDomainInfo(origin);
    
    try {
        // Fetch Google reviews and get manual Yelp response
        const [googleResponse, yelpResponse] = await Promise.allSettled([
            handleGoogleReviews(env, corsHeaders, origin).then(res => res.json()),
            handleYelpReviewsManual(corsHeaders, origin).then(res => res.json())
        ]);

        const googleData = googleResponse.status === 'fulfilled' ? googleResponse.value : { reviews: [], fallback: true };
        const yelpData = yelpResponse.status === 'fulfilled' ? yelpResponse.value : { reviews: [], manual: true };

        const combinedData = {
            success: true,
            google: {
                reviews: googleData.reviews || [],
                summary: googleData.summary || { rating: 5.0, total_ratings: 0 },
                fallback: googleData.fallback || false,
                error: googleData.error || null,
                method: 'api'
            },
            yelp: {
                reviews: yelpData.reviews || [],
                summary: yelpData.summary || { rating: 5.0, review_count: 8 },
                fallback: false, // Manual reviews are not fallback
                error: null,
                method: 'manual',
                note: 'Using manually curated reviews for quality control'
            },
            combined_stats: {
                total_api_reviews: (googleData.reviews?.length || 0),
                manual_yelp_reviews: 8, // Update when you add more
                google_rating: googleData.summary?.rating || 5.0,
                yelp_rating: 5.0,
                has_errors: !!(googleData.error),
                using_fallback: !!(googleData.fallback)
            },
            strategy: {
                google: 'live_api',
                yelp: 'manual_curation',
                benefits: 'Quality control + cost optimization'
            },
            domain_info: domainInfo,
            timestamp: new Date().toISOString(),
            api_version: '2.4'
        };

        return new Response(JSON.stringify(combinedData), {
            headers: { 
                ...corsHeaders, 
                'Content-Type': 'application/json',
                'Cache-Control': 'public, max-age=900, s-maxage=900'
            }
        });

    } catch (error) {
        console.error('805 LifeGuard: Combined reviews error for', domainInfo.environment, ':', error);
        return new Response(JSON.stringify({ 
            error: 'Failed to fetch combined reviews',
            message: error.message,
            fallback: true,
            domain_info: domainInfo,
            timestamp: new Date().toISOString()
        }), { 
            status: 500, 
            headers: { 
                ...corsHeaders, 
                'Content-Type': 'application/json' 
            } 
        });
    }
}

// === UTILITY FUNCTIONS ===

async function fetchWithTimeout(url, options, timeoutMs) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    
    try {
        const response = await fetch(url, {
            ...options,
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        return response;
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            throw new Error('Request timeout');
        }
        throw error;
    }
}

function sanitizeText(text) {
    if (!text) return '';
    
    return text
        .replace(/[<>]/g, '')
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;')
        .replace(/\s+/g, ' ')
        .trim()
        .substring(0, 800);
}

// === DEPLOYMENT CONFIGURATION ===
/*

PRODUCTION DEPLOYMENT - MANUAL YELP STRATEGY:

STEP 1: UPDATE CLOUDFLARE WORKER
1. Replace your existing worker code with this version
2. Deploy the changes

STEP 2: ENVIRONMENT VARIABLES NEEDED
- GOOGLE_PLACES_API_KEY: Your Google Places API key
- GOOGLE_PLACE_ID: ChIJF_n_aeIx6IARDaz-6Q4-Hec

STEP 3: EXPECTED RESULTS
✅ Google API: Live reviews from Google Places
✅ Yelp Reviews: Manual reviews from your HTML (high quality)
✅ Cost Optimization: No Yelp API fees
✅ Quality Control: Curated Yelp reviews only
✅ Production Ready: System ready for domain switch

FEATURES:
✅ Manual Yelp reviews (cost-effective)
✅ Live Google reviews (authentic)
✅ Multi-domain support (staging/production)
✅ Graceful fallback handling
✅ Production-ready configuration

When you add new Yelp reviews manually:
1. Add them to your HTML testimonials section
2. Update the review_count in the manual handler (line 241)
3. Update manual_yelp_reviews count (line 328)

*/